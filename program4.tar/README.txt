Name: Mujtaba Aljabery 
ONID: 933966803 
Class: CS 162 section #001 
Date: August 16, 2021 
 
 This README.txt file is for CS 162 section #001's assignment #4, which is about Linked lists.

   None of the extra credits are done in this program, this follows the original guideline of having the sort merge algorithm 
for both the sort_ascending() and sort_descending() functions. 


 Description:  
    
    This program will start by taking in user inputs in the form of numbers. If it's not a number, 
 it will error handle it until it is a number. Once a number is entered, it will ask the user if they would like to add another number. 
 These numbers are nodes that will be inserted into a Linked list, which once the user hits no, it will stop adding to the Linked list.  
 
   Right after, it will prompt them if they would like to have their list assorted in either ascending or descending order. 
Once the user chooses either option, it will print it in that chosen order. After the list is printed, it will also print 
how many prime numbers that are in their linked list. 

   It will ask the user if they would like to re-do the operation, which if chosen yes, will clean the list and 
start over from the beginning. The error handling is done using while loops and the entire main function has multiple do loops that
maintain the flow of the application. 


Notes: 

   1. Instead of typing everything at once, try typing "Make operation". By doing so, it will do make clean, make, and make run all simultaneously. 
   2. To play with the insert function, just simply type something like "insert(2, 5). This should insert a value of 2 at index 5. 



Thank you Jun and Professor Coker for a great term! You guys rock! 
Enjoy the rest of Summer and hope to see you in the upcoming fall season! 